"use client";
import { useState } from "react";
import MapaDeAssentos from "./componentes/MapaDeAssentos";
import DetalhesDoFilme from "./componentes/DetalhesDoFilme";
import Legenda from "./componentes/Legenda";
import BotaoTrocaTema from "./componentes/BotaoTrocaTema";
import estilos from "./estilos/page.module.css";

const filme = {
  titulo: "O lobo de Wall street",
  horario: "18:30",
  sinopse:
    "Jordan Belfort é um ambicioso corretor da bolsa de valores que cria um verdadeiro império, enriquecendo de forma rápida, porém ilegal. Ele e seus amigos mergulham em um mundo de excessos, mas seus métodos ilícitos despertam a atenção da polícia.",
  dataDeLancamento: "26 de setembro de 2024 (Brasil)",
  diretor: "Martin Scorsese",
};

export default function PaginaPrincipal() {
  const [assentos, setAssentos] = useState(
    Array.from({ length: 60 }, (_, index) => ({
      id: index + 1,
      tipo: index % 10 === 0 ? "especial" : "normal", // Assentos especiais a cada 10
      status: index % 5 === 0 ? "indisponivel" : "disponivel", // Alguns indisponíveis
      selecionado: false,
    }))
  );

  const [valorTotal, setValorTotal] = useState(0);

  const aoSelecionarAssento = (id) => {
    setAssentos((assentosAnteriores) =>
      assentosAnteriores.map((assento) =>
        assento.id === id
          ? {
              ...assento,
              selecionado: !assento.selecionado,
            }
          : assento
      )
    );

    // Atualizar valor total com base nos assentos selecionados
    const assento = assentos.find((assento) => assento.id === id);
    if (assento.status === "disponivel") {
      setValorTotal((total) =>
        assento.selecionado ? total - 25 : total + 25
      ); // Considerando R$ 25 por assento
    }
  };

  const realizarCompra = () => {
    alert("Compra realizada com sucesso!");
  };

  return (
    <div className={estilos.container}>
      <BotaoTrocaTema />
      <div className={estilos.conteudo}>
        {/* Dividindo a tela em mapa de assentos e detalhes */}
        <div className={estilos.colunaMapa}>
          <MapaDeAssentos assentos={assentos} aoSelecionarAssento={aoSelecionarAssento} />
          <Legenda />
        </div>
        <div className={estilos.colunaDetalhes}>
          <DetalhesDoFilme filme={filme} />
        </div>
      </div>
      <button className={estilos.botaoCompra} onClick={realizarCompra}>
        Comprar - R$ {valorTotal.toFixed(2)}
      </button>
    </div>
  );
}
