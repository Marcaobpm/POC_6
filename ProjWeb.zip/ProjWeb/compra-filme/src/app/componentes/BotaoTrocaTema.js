"use client";

import { useState, useEffect } from "react";

export default function BotaoTrocaTema() {
  const [tema, setTema] = useState("dark");

  useEffect(() => {
    document.body.className = tema;
  }, [tema]);

  return (
    <button
      style={{
        position: "fixed",
        top: "20px",
        right: "20px",
        padding: "10px 20px",
        backgroundColor: "#ff5757",
        color: "#fff",
        border: "none",
        borderRadius: "5px",
        cursor: "pointer",
      }}
      onClick={() => setTema(tema === "dark" ? "light" : "dark")}
    >
      {tema === "dark" ? "Modo Claro" : "Modo Escuro"}
    </button>
  );
}
