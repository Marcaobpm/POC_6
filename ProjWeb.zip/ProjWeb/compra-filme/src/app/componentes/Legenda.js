import estilos from "../estilos/Legenda.module.css";

export default function Legenda() {
  return (
    <div className={estilos.legenda}>
      <div className={estilos.item}>
        <div className={`${estilos.circulo} ${estilos.livre}`}></div>
        <span>Disponível</span>
      </div>
      <div className={estilos.item}>
        <div className={`${estilos.circulo} ${estilos.selecionado}`}></div>
        <span>Selecionado</span>
      </div>
      <div className={estilos.item}>
        <div className={`${estilos.circulo} ${estilos.indisponivel}`}></div>
        <span>Indisponível</span>
      </div>
      <div className={estilos.item}>
        <div className={`${estilos.circulo} ${estilos.especial}`}></div>
        <span>Especial</span>
      </div>
    </div>
  );
}
