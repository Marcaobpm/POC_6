import estilos from "../estilos/MapaDeAssentos.module.css";

export default function MapaDeAssentos({ assentos, aoSelecionarAssento }) {
  return (
    <div>
      <div className={estilos.container}>
        {assentos.map((assento) => (
          <div
            key={assento.id}
            className={`${estilos.assento} ${
              estilos[assento.status]
            } ${assento.tipo === "especial" ? estilos.especial : ""} ${
              assento.selecionado ? estilos.selecionado : ""
            }`}
            onClick={() =>
              assento.status === "disponivel" && aoSelecionarAssento(assento.id)
            }
          ></div>
        ))}
      </div>
      <div className={estilos.tela}>tela</div> {/* Mantém a tela no final */}
    </div>
  );
}
