import estilos from "../estilos/DetalhesDoFilme.module.css";

export default function DetalhesDoFilme({ filme }) {
  return (
    <div className={estilos.container}>
      <h2>{filme.titulo}</h2>
      <p><strong>Horário:</strong> {filme.horario}</p>
      <p><strong>Sinopse:</strong> {filme.sinopse}</p>
      <p><strong>Data de lançamento:</strong> {filme.dataDeLancamento}</p>
      <p><strong>Direção:</strong> {filme.diretor}</p>
    </div>
  );
}
