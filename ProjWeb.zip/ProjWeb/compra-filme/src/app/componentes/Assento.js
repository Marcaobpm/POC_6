import estilos from "../estilos/Assento.module.css";

export default function Assento({ assento, selecionado, aoClicar }) {
  const estiloAssento =
    assento.tipo === "especial"
      ? estilos.especial
      : assento.status === "indisponivel"
      ? estilos.indisponivel
      : estilos.livre;

  return (
    <div
      className={`${estilos.assento} ${estiloAssento} ${
        selecionado ? estilos.selecionado : ""
      }`}
      onClick={assento.status === "disponivel" ? aoClicar : undefined}
    >
      {assento.id}
    </div>
  );
}
